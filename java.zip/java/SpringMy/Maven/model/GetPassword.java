package SpringMy.Maven.model;

public class GetPassword {
	
	String email;

	public GetPassword() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public GetPassword(String email) {
		super();
		this.email = email;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	

}
