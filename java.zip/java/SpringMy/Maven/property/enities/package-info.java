/**
 * 
 */
/**
 * @author echnchy
 *
 */
package SpringMy.Maven.property.enities;