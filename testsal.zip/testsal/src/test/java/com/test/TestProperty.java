package com.test;

import SpringMy.Maven.Utility.CommonUtil;

public class TestProperty {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     
		CommonUtil commonUtil = new CommonUtil();
		//commonUtil.readPropertyFile("/WEB-INF/config/lastid.properties", "db.lastId");
	}

}
