/**
 * 
 */
/**
 * @author echnchy
 *
 */
package SpringMy.Maven.db.enities;