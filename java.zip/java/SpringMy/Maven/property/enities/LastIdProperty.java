package SpringMy.Maven.property.enities;

public class LastIdProperty {

	private String lastId;	
	
	public LastIdProperty() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public LastIdProperty(String lastId) {
		super();
		this.lastId = lastId;
	}
	
	public String getLastId() {
		return lastId;
	}

	public void setLastId(String lastId) {
		this.lastId = lastId;
	}

}
